import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import torch.optim as optim
from sklearn.metrics import accuracy_score, confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import time

# Define the neural network model
class NeuralNetworkModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(NeuralNetworkModel, self).__init__()
        self.Layer1 = nn.Linear(input_size, hidden_size) # Define the linear transformation from input to hidden layer 1, takes the input act as input layer
        self.Layer2 = nn.Linear(hidden_size, hidden_size)# Define the linear transformation from hidden layer 1 to hidden layer 2, means hidden layer 2 takes the output of hidden layer1 as the input
        self.Layer3 = nn.Linear(hidden_size, hidden_size)# Define the linear transformation from hidden layer 2 to hidden layer 3,means hidden layer 3  takes the output of hidden layer2 as the input
        self.Layer4 = nn.Linear(hidden_size, output_size)# # Define the linear transformation from hidden layer 3 to hidden layer4(output layer), means output layer takes output of hidden layer 3 as the input
        self.activation = nn.ReLU()  # ReLU activation function
    def forward(self, x):
        x = self.activation(self.Layer1(x)) # Pass input to hidden layer1 (act as input layer),and apply acitivation to produce output from the weighted sum
        x = self.activation(self.Layer2(x))# Passes output of hidden layer 1 to hidden layer 2 and apply acitivation to produce output from the weighted sum
        x = self.activation(self.Layer3(x))# Passes output of hidden layer 2 to hidden layer 3 and apply acitivation to produce output from the weighted sum
        x = self.Layer4(x)## Passes output of hidden layer 3 to hidden layer 4 (output layer), which also calculates the weighted sum. These weighted sums from each neuron of the output layer are also known as 
        ##logits(vector in whihc each value corresponds to the wegihted sum of each neuron ), activaton function is autommatically applied by loss functio 
        return x # returns the output 
   ## Summary of Forward Propagation :
    ## Each hidden layer in the forward pass takes the output of the previous layer as its input, and then each layer takes the weighted sum(the dot product of the input and associated weights)
    ## (Basically, each neuron in the hidden layer takes the dot product of the input it receives and the weights, then applies an activation function and sends the output of the activation function to neurons of the next layer.)
    ## Each hidden layer takes the output of the previous layer as input, calculates the weighted sum, and then applies an activation function.
    ## But in the last hidden layer, also known as the output layer, each neuron calculates the weighted sum but doesn't apply the activation function. These weighted sums from each neuron are sent to a final
    ## activation function as logits (a vector containing the weighted sum associated with each neuron), and then the softmax activation function in the cross entropy loss function produces a probability distribution. Each probability in the probability distribution is associated with each neuron in the output layer, and these neurons
    ## denote correspont to each class. The class with the highest probability is the final output.
criterion = nn.CrossEntropyLoss()# Applies the softmax activation function to logits, and then calculates the loss by measuring the difference between predicted results and actual result
def evaluate_model(model, images, labels):
    model.eval()## Set the model to evaluation mode
    with torch.no_grad():
        Model_outputs = model(images) # Compute model output by sending the images(inputs) to the NeuralNetworkModel
    Model_predicted_labels = torch.argmax(Model_outputs, dim=1).numpy()# From the results, it finds the index of the class with highest probability
    model_accuracy = accuracy_score(labels.numpy(), Model_predicted_labels)# calculates the accuracy by measuring difference between predicted result and actual results
    print(f'Accuracy: {model_accuracy:.4f}')
    Model_ConfusionMatrix = confusion_matrix(labels.numpy(), Model_predicted_labels)# Computes the confusion matrix
    print('Confusion Matrix:')
    print(Model_ConfusionMatrix)
    ## Creates a confuson matrix 
    fig_Matrix = plt.figure(figsize=(5, 5))
    matrix = Model_ConfusionMatrix
    sns.heatmap(matrix.T, square=True, annot=True, cbar=False, cmap=plt.cm.Blues, fmt='d')
    plt.xlabel('Predicted Values')
    plt.ylabel('Actual Values')
    plt.show()
  # Visualize images with actual and predicted labels
    num_of_images = min(10, len(images))  # Limit the number of examples to visualize
    fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(15, 6)) ##Create subplots with 2 rows and 5 columns, with a specific figure size
    axes = axes.flatten()# Flatten the axes array for easier iteration
    for i in range(num_of_images): # Iterate over the images to visualize
        axes[i].imshow(images_correct[i].reshape(28, 28), cmap="gray")# Display the image at index i reshaped to 28x28, using grayscale colormap
        axes[i].set_title(f"Actual: {labels[i]}, Predicted: {Model_predicted_labels[i]}") # Set title for each subplot displaying the actual and predicted labels
        axes[i].axis("off") # Turn off axis for better visualization

    plt.tight_layout()# Adjust layout to prevent overlap
    plt.show()# Show the plot
    return model_accuracy
# Function to save predictions to CSV
def testfile(predictions, file_path):
    pd.DataFrame({'ImageID': range(1, len(predictions) + 1), 'Label': predictions}).to_csv(file_path, index=False)
# Load and preprocess the data
train_data_file_path = 'train.csv' # Path to the training data 
test_data_file_path = 'test.csv'# Path to the  testing data
train_data = pd.read_csv(train_data_file_path)# Read and stores the trainnig data
test_data = pd.read_csv(test_data_file_path)# Read and stores the testing data

X_train = train_data.iloc[:, 1:].values / 255.0 ## Extracts the pixcel values of images and normlaize them bu dividing them by 255
y_train = train_data.iloc[:, 0].values ## Extracts the labels
X_test = test_data.values / 255.0 #Extracts the pixcel values of images from testing data and normlaize them by dividing them by 255
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2,random_state=42)# Split data into training and validation sets
# Convert data to PyTorch tensors
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.long)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
y_val_tensor = torch.tensor(y_val, dtype=torch.long)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)

train_dataSet = TensorDataset(X_train_tensor, y_train_tensor)# Converts training data images and labels into pairs
train_data_loader =DataLoader(train_dataSet, batch_size=75,shuffle=False)# converts the pairs into single data points, size =75 means set of 75 is send
validaton_dataset = TensorDataset(X_val_tensor, y_val_tensor)# Converts validation data images and labels into pairs to print images
validation_data_loader = DataLoader(validaton_dataset, batch_size=20, shuffle=False)  # # converts the pairs into single data points, size =20 means set of 20 is send
# Define image labels for visualization
images_correct, labels = next(iter(validation_data_loader))

input_size = 28 * 28 ## number of pixcels(784)
output_size = 10 # number of classes(0-9)
## Hyperparameters
hidden_size = 600 
epochs = 50
learning_rate = 0.01
# Start timing to calculate build time
start_time = time.time()
neural_network_model = NeuralNetworkModel(input_size, hidden_size, output_size)# creating an instance of Model class
optimizer = optim.Adagrad(neural_network_model.parameters(), lr=learning_rate)# creating an instance of Optimizaton class
# Training loop
for epoch in range(epochs):
    for input_images, labels in train_data_loader:# Iterate over batches of images and labels from the training data loader
        input_images = input_images.view(-1, input_size)# Convert each image to a 1D array
        model_output = neural_network_model(input_images) # sends the input(flattened 1D vector) to neural network, whihc applied forward propogation and compute the model's output logits for the input images
        loss = criterion(model_output, labels) # Compute the loss between the model's predictions and the true labels
        optimizer.zero_grad() # Clear the gradients of all optimized parameters
        loss.backward()# Backward pass: compute gradients of the loss with respect to model parameters
        optimizer.step()# Update the model parameters using the computed gradients
# End timing
end_time = time.time()
# Calculate build time
elapsed_time = end_time - start_time
print(f"Time taken to build the model: {elapsed_time:.2f} seconds")
# # Evaluate on validation set
print("Validation Set:")
evaluate_model(neural_network_model, X_val_tensor, y_val_tensor)# Evaluate the model on the validation set and print the results
# Predict on test set
X_test_flattened = X_test.reshape(-1, input_size)# Reshape each image to a 1D array
X_test_tensor = torch.tensor(X_test_flattened, dtype=torch.float32)# converts 1D array into torce
with torch.no_grad():
    Test_outputs = neural_network_model(X_test_tensor)## sends the 1D vector of test images to neural_network_model class to get the predcted results
model_predicted_labels = torch.argmax(Test_outputs, dim=1).numpy()### From the results, it finds the index of the class with highest probability, which is the fnal output
# Save predictions to CSV
testfile(model_predicted_labels, 'Test_labels.csv')## saves the final output(label)
